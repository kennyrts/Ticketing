package com.example.ticketing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketingApplicationTests {

	@Test
	void contextLoads() {
	}

}
